package com.pharmacy.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcConnection {
	// TODO Auto-generated method stub

	static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3307/drugdatabase";
	static final String USER = "root";
	static final String PASS = "Database@123"; 

	public static Connection getConncetion()
	{
		Connection con = null;
		try {
			Class.forName(DRIVER).newInstance();
			con = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (Exception e) {
			System.err.println("Cannot connect to database server:");
			System.out.println(e.getMessage());
		}
		return con;
	}
}